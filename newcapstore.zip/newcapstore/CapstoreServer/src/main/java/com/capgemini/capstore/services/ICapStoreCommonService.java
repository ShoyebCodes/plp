package com.capgemini.capstore.services;

import javax.validation.Valid;

import com.capgemini.capstore.beans.User;

public interface ICapStoreCommonService {

	boolean ValidateLogIn(@Valid User user);

	User isValidEmail(String email);

	boolean checkSequirityAnswer(String attribute, String securityAnswer);

	void updatePassword(String email, String password);

	boolean changePassword(String attribute, String oldPassword, String newPassword);

	boolean ValidateUserDetails(@Valid User user);

}
